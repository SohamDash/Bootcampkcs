﻿using System;

namespace MemberModelClassList
{
    class Program
    {
        static void Main(string[] args)
        {
            MemberModelClass MMC = new MemberModelClass();

            MMC.Id = 20038;
            MMC.FName = "Soham";
            MMC.LName = "Dash";
            MMC.Contact = "917873491061";
            MMC.Gender = 'M';

            Console.WriteLine("Member Id: " + MMC.Id);
            Console.WriteLine("Member Fname: " + MMC.FName);
            Console.WriteLine("Member Lname: " + MMC.LName);
            Console.WriteLine("Member Contact: " + MMC.Contact);
            Console.WriteLine("Member Gender: " + MMC.Gender);

            int MemberCount;
            List<MemberModelClass> MMCList = new List<MemberModelClass>();

            Console.WriteLine("Enter the no of members to add: ");
            MemberCount = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < MemberCount; i++)
            {
                MemberModelClass MMCObject = new MemberModelClass();

                Console.WriteLine("Enter Member Id: ");
                MMCObject.Id = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Member Fname: ");
                MMCObject.FName = (Console.ReadLine());

                Console.WriteLine("Enter Member Lname: ");
                MMCObject.LName = (Console.ReadLine());

                Console.WriteLine("Enter Member Contact Info: ");
                MMCObject.Contact = (Console.ReadLine());

                Console.WriteLine("Enter Member Gender: ");
                MMCObject.Gender = Convert.ToChar(Console.ReadLine());

                MMCList.Add(MMCObject);
            }


            Console.WriteLine("Member data records are:");
            for (int i = 0; i < MMCList.Count; i++)
            {
                Console.WriteLine("Member Id: " + MMCList[i].Id);
                Console.WriteLine("Member Fname: " + MMCList[i].FName);
                Console.WriteLine("Member Lname: " + MMCList[i].LName);
                Console.WriteLine("Member Contact: " + MMCList[i].Contact);
                Console.WriteLine("Member Gender: " + MMCList[i].Gender);
            }

        }
    }
}